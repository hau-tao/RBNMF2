function s=sigmoid(x)
s=1./(1+exp(-x));