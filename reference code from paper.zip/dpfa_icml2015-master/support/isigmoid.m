function s=isigmoid(x)
s=-log(1./x-1);